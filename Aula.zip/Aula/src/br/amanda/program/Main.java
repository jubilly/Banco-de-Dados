package br.amanda.program;

	public class Main {
		public static void main(String[] args) {
			
			/*----------PROFESSORES----------*/
			Professor albert = new Professor();
			albert.setNome("Albert Einstein");
			Professor isaac = new Professor();
			isaac.setNome("Isaac Newton");
			
			/*-------------SALAS-------------*/
			Sala sala1 = new Sala();
			sala1.setDescricao("Engenharias");
			sala1.setTiposala(TipoSala.TEORICA);
			sala1.setNumero("35");
			
			Sala laboratorio = new Sala();
			laboratorio.setDescricao("Engenharias");
			laboratorio.setTiposala(TipoSala.PRATICA);
			laboratorio.setNumero("50");
			
			/*-------------TURMA-------------*/
			Turma turma = new Turma();
			turma.setSemestre("Segundo Semestre");
			turma.setCurso("Engenharia");
			
			/*------------AULA TEORICA - Albert------------*/
			Aula aulas = new Aula();
			aulas.setProfessor(albert);
			aulas.setConteudos("Impulso e movimento linear");
			aulas.setData("01/07/2015");
			aulas.setSala(sala1);
			aulas.setTurma(turma);
			
			/*------------AULA PRATICA - Albert-------------*/
			Aula aulasp = new Aula();
			aulasp.setProfessor(albert);
			aulasp.setConteudos("Impulso e movimento linear");
			aulasp.setData("03/07/2015");
			aulasp.setSala(laboratorio);
			aulasp.setTurma(turma);
			
			/*------------AULA TEORICA - Isaac-------------*/
			Aula aulas1 = new Aula();
			aulas1.setProfessor(isaac);
			aulas1.setConteudos("Queda livre de corpos");
			aulas1.setData("28/08/2015");
			aulas1.setSala(sala1);
			aulas1.setTurma(turma);
			
			/*------------AULA PRATICA - Isaac-------------*/
			Aula aulasp2 = new Aula();
			aulasp2.setProfessor(isaac);
			aulasp2.setConteudos("Queda livre de corpos");
			aulasp2.setData("03/09/2015");
			aulasp2.setSala(laboratorio);
			aulasp2.setTurma(turma);
			
			System.out.println("\n O professor Albert Einstein ministrou as aulas de "+ aulas.getConteudos()+" no curso de "+turma.getCurso()+"na turma de"+turma.getSemestre()+"no dia"+ aulas.getData()+" na sala" +aulas.getSala());
			System.out.println("\n O professor Isaac Newton ministrou as aulas de "+ aulas1.getConteudos()+" no curso de "+turma.getCurso()+"na turma de"+turma.getSemestre()+"no dia"+ aulas1.getData()+" na sala" +aulas.getSala());
			System.out.println("\n O professor Albert Einstein ministrou as aulas de "+ aulas.getConteudos()+" no curso de "+turma.getCurso()+"na turma de"+turma.getSemestre()+"no dia"+ aulasp.getData()+ "na sala"+laboratorio.getTiposala());
			System.out.println("\n O professor Isaac Newton ministrou as aulas de "+ aulas.getConteudos()+" no curso de "+turma.getCurso()+"na turma de"+turma.getSemestre()+"no dia"+ aulasp2.getData()+ "na sala"+laboratorio.getTiposala());
		}
}