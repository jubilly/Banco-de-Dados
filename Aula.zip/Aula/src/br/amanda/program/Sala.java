package br.amanda.program;

import java.util.List;

public class Sala {
	
		private Long id;
		private String endereco;
		private String numero;
		private TipoSala tiposala;
		private String descricao;
		private List<Aula>aula;
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getEndereco() {
			return endereco;
		}
		public void setEndereco(String endereco) {
			this.endereco = endereco;
		}
		public TipoSala getTiposala() {
			return tiposala;
		}
		public void setTiposala(TipoSala tiposala) {
			this.tiposala = tiposala;
		}
		public List<Aula> getAula() {
			return aula;
		}
		public void setAula(List<Aula> aula) {
			this.aula = aula;
		}
		public String getDescricao() {
			return descricao;
		}
		public void setDescricao(String descricao) {
			this.descricao = descricao;
		}
		public String getNumero() {
			return numero;
		}
		public void setNumero(String numero) {
			this.numero = numero;
		}
}
