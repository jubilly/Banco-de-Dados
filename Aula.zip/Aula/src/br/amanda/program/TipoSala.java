package br.amanda.program;

public enum TipoSala {
	PRATICA,TEORICA;
}
