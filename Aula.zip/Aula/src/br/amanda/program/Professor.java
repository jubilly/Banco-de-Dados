package br.amanda.program;

import java.util.ArrayList;
import java.util.List;

public class Professor {
	private String Nome;
	private Long Id;
	
	private List<Aula> aula = new ArrayList<Aula>();
	
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public List<Aula> getAula() {
		return aula;
	}
	public void setAula(List<Aula> aula) {
		this.aula = aula;
	}

	
}
