package br.amanda.program;


public class Aula {

	private Long id;
	private String conteudos;
	private String data;
	private Professor professor;
	private Sala sala;
	private Turma turma;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getConteudos() {
		return conteudos;
	}
	public void setConteudos(String conteudos) {
		this.conteudos = conteudos;
	}
	public Professor getProfessor() {
		return professor;
	}
	public void setProfessor(Professor professor) {
		this.professor = professor;
	}
	public Sala getSala() {
		return sala;
	}
	public void setSala(Sala sala) {
		this.sala = sala;
	}
	public Turma getTurma() {
		return turma;
	}
	public void setTurma(Turma turma) {
		this.turma = turma;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}

}
