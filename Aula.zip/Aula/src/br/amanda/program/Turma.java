package br.amanda.program;

import java.util.List;

public class Turma {
	private Long Id;
	private String Semestre;
	private String Sala;
	private String Curso;
	private List<Aula>aulas;
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	
	public List<Aula> getAulas() {
		return aulas;
	}
	public void setAulas(List<Aula> aulas) {
		this.aulas = aulas;
	}
	public String getSemestre() {
		return Semestre;
	}
	public void setSemestre(String semestre) {
		Semestre = semestre;
	}
	public String getSala() {
		return Sala;
	}
	public void setSala(String sala) {
		Sala = sala;
	}
	public String getCurso() {
		return Curso;
	}
	public void setCurso(String curso) {
		Curso = curso;
	}
	
}
